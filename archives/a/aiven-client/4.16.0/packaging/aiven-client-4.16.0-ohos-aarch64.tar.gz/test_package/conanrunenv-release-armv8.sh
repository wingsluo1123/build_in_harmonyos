script_folder="/storage/Users/currentUser/Desktop/build_in_harmonyos/archives/a/aiven-client/4.16.0/test_package"
echo "echo Restoring environment" > "$script_folder/deactivate_conanrunenv-release-armv8.sh"
for v in PYTHONPATH
do
   is_defined="true"
   value=$(printenv $v) || is_defined="" || true
   if [ -n "$value" ] || [ -n "$is_defined" ]
   then
       echo export "$v='$value'" >> "$script_folder/deactivate_conanrunenv-release-armv8.sh"
   else
       echo unset $v >> "$script_folder/deactivate_conanrunenv-release-armv8.sh"
   fi
done

export PYTHONPATH="${PYTHONPATH:-}${PYTHONPATH:+:}/storage/Users/currentUser/.conan2/p/b/aivenffed210853d8a/p/lib/python3.12/site-packages"