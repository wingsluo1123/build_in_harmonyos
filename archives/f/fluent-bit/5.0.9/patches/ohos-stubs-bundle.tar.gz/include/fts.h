#ifndef _FTS_H_STUB_
#define _FTS_H_STUB_
/* HarmonyOS stub for musl lacking <fts.h> */
typedef struct { void *fts_cur; } FTS;
typedef struct { char *fts_name; int fts_info; int fts_level; void *fts_ent; } FTSENT;
#define FTS_COMFOLLOW 0x1
#define FTS_LOGICAL 0x2
#define FTS_NOCHDIR 0x4
#define FTS_NOSTAT 0x8
#define FTS_PHYSICAL 0x10
#define FTS_SEEDOT 0x20
#define FTS_PEND 0
static inline FTS *fts_open(char * const *p, int o, int (*c)(const FTSENT**, const FTSENT**)) { return NULL; }
static inline FTSENT *fts_read(FTS *f) { return NULL; }
static inline int fts_close(FTS *f) { return 0; }
#endif
