#ifndef OPENSSL_BIO_H_STUB
#define OPENSSL_BIO_H_STUB
/* HarmonyOS stub */
typedef struct {} BIO;
static inline void *BIO_new_socket(int fd, int c) { return NULL; }
static inline int BIO_write(void *b, const void *d, int l) { return l; }
static inline int BIO_read(void *b, void *d, int l) { return 0; }
static inline int BIO_puts(void *b, const char *s) { return 0; }
static inline int BIO_free(void *b) { return 0; }
#endif
#include <stddef.h>
static inline void *BIO_new_mem_buf(const void *buf, int len) { (void)buf;(void)len; return NULL; }
