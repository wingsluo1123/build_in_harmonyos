#ifndef OPENSSL_EVP_H_STUB
#define OPENSSL_EVP_H_STUB
/* HarmonyOS stub: FLB_TLS=Off, no real OpenSSL available */
typedef struct {} EVP_CIPHER_CTX;
typedef struct {} ENGINE;
typedef struct {} EVP_MD;
#define EVP_MAX_MD_SIZE 64
#define EVP_CTX_FLAG_FIPS 0
static inline int EVP_DigestInit_ex(void *ctx, const void *type, void *e) { return 1; }
static inline int EVP_DigestUpdate(void *ctx, const void *d, size_t n) { return 1; }
static inline int EVP_DigestFinal_ex(void *ctx, unsigned char *md, unsigned int *s) { return 1; }
static inline void *EVP_MD_CTX_new(void) { return NULL; }
static inline void EVP_MD_CTX_free(void *ctx) {}
static inline const void *EVP_get_digestbyname(const char *n) { return NULL; }
static inline int EVP_MD_size(const void *md) { return 32; }
#endif
