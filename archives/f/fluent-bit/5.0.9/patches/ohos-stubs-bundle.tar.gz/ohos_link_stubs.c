/* HarmonyOS link-time stubs for symbols referenced when
   FLB_TLS=Off, FLB_HTTP_SERVER=Off, FLB_SQLDB=Off, etc.
   
   These symbols are called from unconditionally-compiled source files
   even when the corresponding subsystem is disabled. */

#include <stdlib.h>
#include <stddef.h>

/* --- SQLDB stubs (FLB_SQLDB=Off) --- */
void *flb_sqldb_open(void *config, const char *path, void *cb) { return NULL; }
void flb_sqldb_close(void *db) {}
int flb_sqldb_query(void *db, const char *sql, int (*cb)(void*,int,char**,char**), void *data) { return -1; }
int flb_sqldb_execute(void *db, const char *sql) { return -1; }

/* --- HTTP Server stubs (FLB_HTTP_SERVER=Off) --- */
void *flb_http_server_init(void *config) { return NULL; }
int flb_http_server_start(void *server) { return -1; }
void flb_http_server_stop(void *server) {}
void flb_http_server_destroy(void *server) {}

/* --- pthread_cancel stub (musl may define it) --- */
#ifndef HAVE_PTHREAD_CANCEL
int pthread_cancel(void *thread) { return 0; }
#endif
