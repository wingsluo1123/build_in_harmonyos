gnugo 3.8 ohos-aarch64 package
