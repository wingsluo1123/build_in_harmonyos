script_folder="/storage/Users/currentUser/tmp/skill/build_in_harmonyos/archives/g/gphoto2/2.5.32/test_package"
echo "echo Restoring environment" > "$script_folder/deactivate_conanbuildenv-release-armv8.sh"
for v in PATH SHELL CONFIG_SHELL ACLOCAL_PATH LIBTOOLIZE _lt_pkgdatadir
do
   is_defined="true"
   value=$(printenv $v) || is_defined="" || true
   if [ -n "$value" ] || [ -n "$is_defined" ]
   then
       echo export "$v='$value'" >> "$script_folder/deactivate_conanbuildenv-release-armv8.sh"
   else
       echo unset $v >> "$script_folder/deactivate_conanbuildenv-release-armv8.sh"
   fi
done

export PATH="/data/service/hnp/bin:/storage/Users/currentUser/usr/local/bin:${PATH}"
export SHELL="/data/service/hnp/bin/bash"
export CONFIG_SHELL="/data/service/hnp/bin/bash"
export ACLOCAL_PATH="${ACLOCAL_PATH:-}${ACLOCAL_PATH:+:}/storage/Users/currentUser/.conan2/p/libto9be71649e7cec/p/share/aclocal"
export LIBTOOLIZE="/storage/Users/currentUser/.conan2/p/libto9be71649e7cec/p/bin/libtoolize"
export _lt_pkgdatadir="/storage/Users/currentUser/.conan2/p/libto9be71649e7cec/p/share/libtool-conan"