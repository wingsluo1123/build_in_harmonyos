script_folder="/storage/Users/currentUser/tmp/skill/build_in_harmonyos/archives/g/gphoto2/2.5.32/test_package"
echo "echo Restoring environment" > "$script_folder/deactivate_conanrunenv-release-armv8.sh"
for v in PATH LD_LIBRARY_PATH DYLD_LIBRARY_PATH
do
   is_defined="true"
   value=$(printenv $v) || is_defined="" || true
   if [ -n "$value" ] || [ -n "$is_defined" ]
   then
       echo export "$v='$value'" >> "$script_folder/deactivate_conanrunenv-release-armv8.sh"
   else
       echo unset $v >> "$script_folder/deactivate_conanrunenv-release-armv8.sh"
   fi
done

export PATH="/storage/Users/currentUser/.conan2/p/b/gphot149cc678d8509/p/bin:/storage/Users/currentUser/.conan2/p/b/libgp5e4f95ca9e743/p/bin:/storage/Users/currentUser/.conan2/p/libto9be71649e7cec/p/bin${PATH:+:$PATH}"
export LD_LIBRARY_PATH="/storage/Users/currentUser/.conan2/p/b/libgp5e4f95ca9e743/p/lib:/storage/Users/currentUser/.conan2/p/libto9be71649e7cec/p/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export DYLD_LIBRARY_PATH="/storage/Users/currentUser/.conan2/p/b/libgp5e4f95ca9e743/p/lib:/storage/Users/currentUser/.conan2/p/libto9be71649e7cec/p/lib${DYLD_LIBRARY_PATH:+:$DYLD_LIBRARY_PATH}"