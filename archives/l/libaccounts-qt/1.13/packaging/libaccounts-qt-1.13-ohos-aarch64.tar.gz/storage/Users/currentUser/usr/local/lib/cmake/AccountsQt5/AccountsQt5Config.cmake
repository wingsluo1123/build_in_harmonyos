#  ACCOUNTSQT_INCLUDE_DIRS - The libaccounts-qt include directories
#  ACCOUNTSQT_LIBRARIES - The libraries needed to use libaccounts-qt

set(ACCOUNTSQT_LIBRARIES /storage/Users/currentUser/usr/local/lib/libaccounts-qt5.so)
set(ACCOUNTSQT_INCLUDE_DIRS /storage/Users/currentUser/usr/local/include/accounts-qt5/)