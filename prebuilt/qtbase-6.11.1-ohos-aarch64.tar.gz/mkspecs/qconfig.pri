QT_ARCH = arm64
QT_BUILDABI = 
QT_LIBCPP_ABI_TAG = 
QT.global.enabled_features = version_tagging shared pkg-config rpath signaling_nan zstd thread future concurrent opensslv30 test_gui test_squish shared trivial_auto_var_init_pattern stack_protector libcpp_hardening relro_now_linker shared rpath reduce_exports openssl
QT.global.disabled_features = static cross_compile debug_and_release separate_debug_info appstore-compliant simulator_and_device force_asserts framework c++20 c++2a c++2b c++2c reduce_relocations wasm-simd128 wasm-exceptions wasm-jspi dbus openssl-linked opensslv11
QT.global.disabled_features += release build_all
QT_CONFIG += shared rpath reduce_exports openssl release
CONFIG += release  shared plugin_manifest trivial_auto_var_init_pattern stack_protector libcpp_hardening relro_now_linker
QT_VERSION = 6.11.1
QT_MAJOR_VERSION = 6
QT_MINOR_VERSION = 11
QT_PATCH_VERSION = 1

QT_CLANG_MAJOR_VERSION = 15
QT_CLANG_MINOR_VERSION = 0
QT_CLANG_PATCH_VERSION = 4
